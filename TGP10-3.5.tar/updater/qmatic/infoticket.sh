#!/bin/bash
pkill -o chrome || true
INTERFACE="enp1s0"

# Obtener IP, MAC y Máscara de Subred. Se añaden nuevos datos de red.
IP=$(ip addr show $INTERFACE | grep "inet\b" | awk '{print $2}' | cut -d/ -f1)
MAC=$(ip link show $INTERFACE | awk '/ether/ {print $2}')
MASK=$(ip addr show $INTERFACE | grep "inet\b" | awk '{print $2}' | cut -d/ -f2)
HOSTNAME=$(hostname)
DNS=$(grep "nameserver" /etc/resolv.conf | awk '{print $2}' | head -n 1)
ADPCON=$(ip addr show $INTERFACE | grep -q inet &&  echo 'YES' || echo 'NO')

# Crear el mensaje y guardarlo en un archivo temporal
TMP_FILE=$(mktemp)
{
 for i in {1..1}; do
        echo
    done
    echo "TGP10 Info settings:"
    echo "                  "
    echo "Hostname: $HOSTNAME"
    echo "#######################"
    echo "Network Data"
    echo "Ethernet connected: $ADPCON"
    nmcli con show 'Conexión cableada 1' | grep -E 'ipv4.addresses|ipv4.gateway|ipv4.dns:|ipv4.method' | sed 's/ //g'
    echo "#######################"
    echo "Disk usage: $(df -h | awk '$NF=="/"{print $5}')"
    echo "RAM: $(free | awk '/Mem/{printf("%.2f"), $3/$2*100}')%"
    echo "CPU: $(top -bn1 | grep "Cpu(s)" | awk '{print $2+$4}')%"
    echo "#######################"
    echo "System V: 3.5"
 for i in {1..3}; do
        echo
    done
    echo -e "\x1B\x69" # Comando de corte de papel

} > "$TMP_FILE"

# Enviar el archivo a la impresora usando CUPS
lp -o 'raw' -d PP-9000 "$TMP_FILE"

# Eliminar el archivo temporal
rm "$TMP_FILE"


export DISPLAY=:0

sleep 1

/bin/bash /home/qmatic/agentbrowser.sh
