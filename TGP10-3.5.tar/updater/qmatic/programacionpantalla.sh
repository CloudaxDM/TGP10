#!/bin/bash
# Obtiene la hora y minutos actuales en formato de 24 horas
hora_actual=$(date "+%k")
minutos_actual=$(date +%M)
hora_min=$((hora_actual * 60))
tiempo_actual=$((hora_min + minutos_actual))

# Define las horas y minutos de apagado y encendido convertidos a minutos desde medianoche
hora_apagado=22
minutos_apagado=49
hora_encendido=07
minutos_encendido=31
tiempo_apagado=$((hora_apagado * 60 + minutos_apagado))
tiempo_encendido=$((hora_encendido * 60 + minutos_encendido))
export DISPLAY=:0

# Verifica si estamos en el período de encendido
if [ $tiempo_actual -ge $tiempo_encendido ] && [ $tiempo_actual -lt $tiempo_apagado ]; then
    /usr/bin/xset dpms force on
else
#    echo $tiempo_apagado
#    echo $hora_actual
    /usr/bin/xset dpms force off
fi
