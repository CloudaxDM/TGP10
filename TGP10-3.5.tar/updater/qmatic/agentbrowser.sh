google-chrome --kiosk --simulate-outdated-no-au='01 jan 2999' /home/qmatic/new.html
